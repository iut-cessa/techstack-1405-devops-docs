import os
from flask import Flask, jsonify

try:
    import psycopg2
except ImportError:
    psycopg2 = None

app = Flask(__name__)

APP_VERSION = os.getenv("APP_VERSION", "dev")
DB_HOST = os.getenv("DB_HOST", "db")
DB_NAME = os.getenv("DB_NAME", "devops_db")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")


def check_db():
    if not psycopg2:
        return False
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            connect_timeout=2
        )
        conn.close()
        return True
    except Exception:
        return False


@app.route("/")
def index():
    return jsonify({
        "status": "running",
        "service": "devops-webapp",
        "version": APP_VERSION
    })


@app.route("/health")
def health():
    db_ok = check_db()
    return jsonify({
        "healthy": db_ok,
        "database": "connected" if db_ok else "disconnected",
        "version": APP_VERSION
    }), 200 if db_ok else 503


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
