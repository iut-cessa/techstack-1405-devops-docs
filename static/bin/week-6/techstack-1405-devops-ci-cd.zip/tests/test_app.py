from pathlib import Path
import sys

import pytest

# Add project root to sys.path for standalone test execution
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import app  # noqa: E402


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_index_route(client):
    response = client.get("/")
    assert response.status_code == 200
    data = response.get_json()
    assert data["status"] == "running"
    assert "version" in data


def test_health_route_exists(client):
    response = client.get("/health")
    assert response.status_code in [200, 503]
